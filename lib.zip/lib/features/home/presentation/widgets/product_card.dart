import 'package:flutter/material.dart';

import '../../domain/entities/product.dart';

class ProductCard extends StatelessWidget {

  final Product product;

  const ProductCard({
    super.key,
    required this.product,
  });

  @override
  Widget build(BuildContext context) {

    return Card(

      child: Padding(
        padding: const EdgeInsets.all(12),

        child: Column(

          children: [

            Image.network(
              product.image,
              height: 120,
              errorBuilder: (context, error, stackTrace) {
                return const SizedBox(
                  height: 120,
                  child: Center(
                    child: Icon(Icons.image_not_supported_outlined),
                  ),
                );
              },
            ),

            const SizedBox(height: 10),

            Text(
              product.title,
              maxLines: 2,
            ),

            const SizedBox(height: 8),

            Text(
              "₹${product.price}",
            ),

          ],

        ),

      ),

    );

  }

}
