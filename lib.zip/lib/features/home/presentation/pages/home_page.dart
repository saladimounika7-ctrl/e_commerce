import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/home_provider.dart';
import '../widgets/product_card.dart';

class HomePage extends ConsumerStatefulWidget {

  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() =>
      _HomePageState();
}

class _HomePageState
    extends ConsumerState<HomePage> {

  @override
  void initState() {
    super.initState();

    Future.microtask(() {

      ref
          .read(homeControllerProvider.notifier)
          .loadProducts();

    });
  }

  @override
  Widget build(BuildContext context) {

    final state =
        ref.watch(homeControllerProvider);

    return Scaffold(

      appBar: AppBar(
        title: const Text(
          "Products",
        ),
      ),

      body: state.when(

        data: (products) {

          return ListView.builder(

            itemCount: products.length,

            itemBuilder: (_, index) {

              return ProductCard(
                product: products[index],
              );

            },

          );

        },

        loading: () {

          return const Center(
            child:
                CircularProgressIndicator(),
          );

        },

        error: (error, stackTrace) {

          return Center(
            child: Text(
              error.toString(),
            ),
          );

        },

      ),

    );

  }

}